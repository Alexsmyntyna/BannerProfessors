package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import java.util.List;

public class BannerUtil {
    private static WebDriver driver = new ChromeDriver();
    private static String BANNER_URL = "https://ggc.gabest.usg.edu/pls/B400/bwckschd.p_disp_dyn_sched";
    static {
        System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
    }


    public static List<Course> getCourses(String name, String subject, String term) {
        driver.get(BANNER_URL);

        Select semesterSelect = new Select(driver.findElement(By.xpath("/html/body/div[3]/form/table/tbody/tr/td/select")));
        int i = 1;
        while(true){
            //breaks if the ITEC course doesn't exist
            semesterSelect.selectByIndex(i);
            if(semesterSelect.getFirstSelectedOption().getText().contains(term)){
                break;
            }
            i++;
        }
        WebElement submitButton = driver.findElement(By.xpath("/html/body/div[3]/form/input[2]"));
        submitButton.click();

        Select selectSubject = new Select(driver.findElement(By.xpath("//*[@id=\"subj_id\"]")));
        selectSubject.selectByValue(subject);

        //Clicking Class search button
        driver.findElement(By.xpath("/html/body/div[3]/form/input[12]")).click();

        ///html/body/div[3]/table[1]

        WebElement fullTable = driver.findElement(By.xpath("/html/body/div[3]/table[1]"));
        List<WebElement> courseRows = fullTable.findElements(By.xpath("/html/body/div[3]/table[1]/tbody/tr"));
        //Requires increment's by 2 to skip the headers
        for (int j = 0; j < courseRows.size(); j += 2) {
            WebElement link = courseRows.get(j).findElement(By.tagName("a"));
            String courseName = link.getText().substring(0,link.getText().indexOf("-")).trim();
            System.out.println(courseName);
        }



        return null;

    }
}
