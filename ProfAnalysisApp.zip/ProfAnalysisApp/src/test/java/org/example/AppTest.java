package org.example;

import static org.junit.Assert.assertTrue;

import org.junit.Assert;
import org.junit.Test;

import java.util.List;

/**
 * Unit test for simple App.
 */
public class AppTest 
{




    @Test
    public void testGetCourses(){
        List<Course> courses = BannerUtil.getCourses("Tacksoo Im", "ITEC" , "Spring 2021");
        Assert.assertEquals(4, courses.size());

    }












}
