package org.example;

import static org.junit.Assert.assertTrue;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Unit test for simple App.
 */
public class AppTest {


    @Test
    public void testGetCourses() {
        List<Course> courses = BannerUtil.getProfCourses("Tacksoo Im", "Spring 2021");
        Assert.assertEquals(4, courses.size());

    }

    @Test
    public void testGetCourses2() {
        List<Course> courses = BannerUtil.getProfCourses("Tacksoo Im", "Fall 2020");
        Assert.assertEquals(4, courses.size());

    }

    @Test
    public void getNumStudents() {
        List<Course> courses = BannerUtil.getProfCourses("Tacksoo Im", "Fall 2020");
        int studentsTotal = 0;
        for (int i = 0; i < courses.size(); i++) {
            studentsTotal += courses.get(i).getNumStudents();
        }
        Assert.assertEquals(87, studentsTotal);

    }


    @Test
    public void getListSemesters() {
        List<String> semesterList = BannerUtil.getListSemester("Fall 2019", "Spring 2021");
        List<String> semesters = new ArrayList<>();
        semesters.add("Fall 2019");
        semesters.add("Spring 2020");
        semesters.add("Summer 2020");
        semesters.add("Fall 2020");
        semesters.add("Spring 2021");
        Assert.assertEquals(semesters, semesterList);
        List<String> semesterList2 = BannerUtil.getListSemester("Summer 2020", "Spring 2021");
        List<String> semesters2 = new ArrayList<>();
        semesters2.add("Summer 2020");
        semesters2.add("Fall 2020");
        semesters2.add("Spring 2021");
        Assert.assertEquals(semesters2, semesterList2);
        List<String> semesterList3 = BannerUtil.getListSemester("Spring 2010", "Fall 2020");
        Assert.assertEquals(33, semesterList3.size());
        Assert.assertEquals(semesterList3.get(3), "Spring 2011");


    }


    @Test
    public void verifyTacksooCourses() throws IOException {
        List<String> semeserList = BannerUtil.getListSemester("Fall 2020", "Spring 2021");
        Assert.assertEquals(2, semeserList.size());
        List<Course> courses = new ArrayList<>();
        for (int i = 0; i < semeserList.size(); i++) {
            List<Course> temp = BannerUtil.getProfCourses("Tacksoo Im", semeserList.get(i));
            for (int j = 0; j < temp.size(); j++) {
                courses.add(temp.get(j));
            }
        }
        Assert.assertEquals(8 , courses.size());

        FileUtils.writeStringToFile(new File("log.txt"),"Fall2020-Spring2021\n", "UTF-8");
        for (int i = 0; i < courses.size(); i++) {
            FileUtils.writeStringToFile(new File("log.txt"),courses.get(i).toString() + "\n", "UTF-8", true);
        }

    }


}
